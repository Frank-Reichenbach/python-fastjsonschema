import ast

import pytest

from fastjsonschema import JsonSchemaDefinitionException, JsonSchemaException, JsonSchemaValueException, RefResolver, compile, compile_to_code, validate


@pytest.mark.parametrize('schema', [
    {'type': 'validate(10)'},
    {'enum': 'validate(10)'},
    {'minLength': 'validate(10)'},
    {'maxLength': 'validate(10)'},
    {'minimum': 'validate(10)'},
    {'maximum': 'validate(10)'},
    {'multipleOf': 'validate(10)'},
    {'minItems': 'validate(10)'},
    {'maxItems': 'validate(10)'},
    {'minProperties': 'validate(10)'},
    {'maxProperties': 'validate(10)'},
    {'required': 'validate(10)'},
    {'exclusiveMinimum': 'validate(10)'},
    {'exclusiveMaximum': 'validate(10)'},
])
def test_not_generate_code_from_definition(schema):
    with pytest.raises(JsonSchemaDefinitionException):
        compile({
            '$schema': 'http://json-schema.org/draft-07/schema',
            **schema
        })


@pytest.mark.parametrize('schema,value', [
    ({'const': 'validate(10)'}, 'validate(10)'),
    ({'pattern': '" + validate("10") + "'}, '"  validate"10"  "'),
    ({'pattern': "' + validate('10') + '"}, '\'  validate\'10\'  \''),
    ({'pattern': "' + validate(\"10\") + '"}, '\'  validate"10"  \''),
    ({'properties': {
        'validate(10)': {'type': 'string'},
    }}, {'validate(10)': '10'}),
    ({'patternProperties': {
        'validate(10)': {'type': 'string'},
    }}, {'validate(10)': '10'}),
])
def test_generate_code_with_proper_variable_names(asserter, schema, value):
    asserter({
        '$schema': 'http://json-schema.org/draft-07/schema',
        **schema
    }, value, value)


def test_dependencies_false_escapes_property_name():
    key = '" + validate("10") + "'
    schema = {
        '$schema': 'http://json-schema.org/draft-07/schema',
        'type': 'object',
        'dependencies': {key: False},
    }
    code = compile_to_code(schema)
    tree = ast.parse(code)
    validate_calls = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == 'validate'
    ]
    assert validate_calls == []

    validator = compile(schema)
    with pytest.raises(JsonSchemaValueException) as exc:
        validator({key: 1})
    assert key in exc.value.message
    assert exc.value.rule == 'dependencies'


@pytest.mark.parametrize('key', ['{foo}', '{data}', '{name_prefix}', '{', '}', '{data.__class__}'])
@pytest.mark.parametrize('fast_fail', [True, False])
@pytest.mark.parametrize('via_ref', [False, True])
def test_property_name_with_braces_is_not_formatted(key, fast_fail, via_ref):
    inner = {'type': 'object', 'properties': {'a': {'type': 'string'}}}
    validator = compile({
        'type': 'object',
        'definitions': {'inner': inner},
        'properties': {
            key: {'$ref': '#/definitions/inner'} if via_ref else inner,
        },
    }, fast_fail=fast_fail)
    with pytest.raises(JsonSchemaException) as exc:
        validator({key: {'a': 1}})
    errors = [exc.value] if fast_fail else exc.value.errors
    assert errors[0].name == 'data.{}.a'.format(key)
    assert errors[0].message == 'data.{}.a must be string'.format(key)


def test_generate_code_without_overriding_variables(asserter):
    # We use variable name by property name. In the code is automatically generated
    # FOO_keys which could colide with keys parameter. Then the variable is reused and
    # for example additionalProperties feature is not working well. We need to make
    # sure the name not colide.
    value = {
        'keys': [1, 2, 3],
    }
    asserter({
        'type': 'object',
        'properties': {
            'keys': {'type': 'array'},
        },
        'additionalProperties': False,
    }, value, value)



def test_deeply_nested_schema_raises_definition_exception():
    schema = generate_deeply_nested_schema(600)

    with pytest.raises(JsonSchemaDefinitionException, match='too deeply nested'):
        RefResolver.from_schema(schema)

    with pytest.raises(JsonSchemaDefinitionException, match='too deeply nested'):
        compile(schema)

    with pytest.raises(JsonSchemaDefinitionException, match='too deeply nested'):
        validate(schema, {'a': {}})


def generate_deeply_nested_schema(depth):
    schema = {'type': 'string'}
    for _ in range(depth):
        schema = {'properties': {'a': schema}}
    return schema

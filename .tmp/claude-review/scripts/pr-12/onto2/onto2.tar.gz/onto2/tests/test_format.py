import datetime
import re

import pytest

from fastjsonschema import JsonSchemaValueException


exc = JsonSchemaValueException('data must be date-time', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value, expected', [
    ('', exc),
    ('bla', exc),
    ('2018-02-05T14:17:10.00', exc),
    ('2018-02-05T14:17:10.00Z\n', exc),
    ('2018-02-05T14:17:10.00Z', '2018-02-05T14:17:10.00Z'),
    ('2018-02-05T14:17:10Z', '2018-02-05T14:17:10Z'),
    ('2020-09-09T01:01:01+0100', '2020-09-09T01:01:01+0100'),
    ('1998-12-31T23:59:60Z', '1998-12-31T23:59:60Z'),
    ('1990-12-31T15:59:60-08:00', '1990-12-31T15:59:60-08:00'),
    ('2020-00-10T01:01:01Z', exc),
    ('2020-13-10T01:01:01Z', exc),
    ('2020-19-10T01:01:01Z', exc),
    ('2020-01-00T01:01:01Z', exc),
    ('2020-01-32T01:01:01Z', exc),
    ('2020-01-39T01:01:01Z', exc),
    ('2020-01-01T24:00:00Z', exc),
    ('2020-01-01T29:00:00Z', exc),
    ('2020-01-01T01:01:61Z', exc),
    ('2020-01-01T01:01:01+24:00', exc),
    ('2020-01-01T01:01:01+01:60', exc),
    ('2020-02-30T01:01:01Z', exc),
    ('2021-02-29T01:01:01Z', exc),
    ('2021-04-31T01:01:01Z', exc),
    ('2020-02-29T01:01:01Z', '2020-02-29T01:01:01Z'),
    ('2021-04-30T01:01:01Z', '2021-04-30T01:01:01Z'),
])
def test_datetime(asserter, value, expected):
    asserter({'type': 'string', 'format': 'date-time'}, value, expected)


exc = JsonSchemaValueException('data must be hostname', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value, expected', [
    ('', exc),
    ('LDhsjf878&d', exc),
    ('bla.bla-', exc),
    ('example.example.com-', exc),
    ('example.example.com\n', exc),
    ('localhost', 'localhost'),
    ('example.com', 'example.com'),
    ('example.de', 'example.de'),
    ('example.fr', 'example.fr'),
    ('example.example.com', 'example.example.com'),
])
def test_hostname(asserter, value, expected):
    asserter({'type': 'string', 'format': 'hostname'}, value, expected)


exc = JsonSchemaValueException('data must be time', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value, expected', [
    ('', exc),
    ('bla', exc),
    ('12:00:00', '12:00:00'),
    ('12:00:00Z', '12:00:00Z'),
    ('00:00:00.5+01:30', '00:00:00.5+01:30'),
    ('23:59:59-23:59', '23:59:59-23:59'),
    ('23:59:60Z', '23:59:60Z'),
    ('24:00:00Z', exc),
    ('29:00:00Z', exc),
    ('99:99:99', exc),
    ('12:60:00Z', exc),
    ('12:00:61Z', exc),
    ('12:00:00+24:00', exc),
    ('12:00:00+00:60', exc),
])
def test_time(asserter, value, expected):
    asserter({
        '$schema': 'http://json-schema.org/draft-07/schema',
        'format': 'time',
    }, value, expected)


exc = JsonSchemaValueException('data must be date', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value, expected', [
    ('', exc),
    ('bla', exc),
    ('2018-2-5', exc),
    ('2018-02-05', '2018-02-05'),
    ('2018-10-31', '2018-10-31'),
    ('2018-02-29', exc),
    ('2018-02-30', exc),
    ('2018-04-31', exc),
    ('2018-06-31', exc),
    ('2018-09-31', exc),
    ('2018-11-31', exc),
    ('1900-02-29', exc),
    ('2100-02-29', exc),
    ('2020-02-29', '2020-02-29'),
    ('2000-02-29', '2000-02-29'),
    ('2400-02-29', '2400-02-29'),
    ('2018-02-28', '2018-02-28'),
    ('2018-04-30', '2018-04-30'),
    ('2018-12-31', '2018-12-31'),
])
def test_date(asserter, value, expected):
    asserter({
        '$schema': 'http://json-schema.org/draft-07/schema',
        'format': 'date',
    }, value, expected)


exc = JsonSchemaValueException('data must be ipv4', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value, expected', [
    ('', exc),
    ('bla', exc),
    ('03.04.05', exc),
    ('2001:db8::1:1', exc),
    ('::ffff:1.1.1.1', exc),
    # Leading zeros must be rejected (octal interpretation, CVE-2021-28918).
    ('01.2.3.4', exc),
    ('1.2.3.04', exc),
    ('00.1.2.3', exc),
    ('1.1.1.1', '1.1.1.1'),
    ('192.168.0.1', '192.168.0.1'),
])
def test_ipv4(asserter, value, expected):
    asserter({'type': 'string', 'format': 'ipv4'}, value, expected)


exc = JsonSchemaValueException('data must be ipv6', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value, expected', [
    ('', exc),
    ('bla', exc),
    ('1.1.1.1', exc),
    ('2001:db8::1:1', '2001:db8::1:1'),
    ('::ffff:1.1.1.1', '::ffff:1.1.1.1'),
    # One group before '::', the rest after it.
    ('1::2:3:4:5:6', '1::2:3:4:5:6'),
    ('1::2:3:4:1.2.3.4', '1::2:3:4:1.2.3.4'),
    ('1::2:3:4:5:6:7:8', exc),
])
def test_ipv6(asserter, value, expected):
    asserter({'type': 'string', 'format': 'ipv6'}, value, expected)


exc = JsonSchemaValueException('data must be custom-format', value='{data}', name='data', definition='{definition}', rule='format')
@pytest.mark.parametrize('value,expected,custom_format', [
    ('', exc, r'^[ab]$'),
    ('', exc, lambda value: value in ('a', 'b')),
    ('a', 'a', r'^[ab]$'),
    ('a', 'a', lambda value: value in ('a', 'b')),
    ('c', exc, r'^[ab]$'),
    ('c', exc, lambda value: value in ('a', 'b')),
])
def test_custom_format(asserter, value, expected, custom_format):
    asserter({'format': 'custom-format'}, value, expected, formats={
        'custom-format': custom_format,
    })


def test_custom_format_override(asserter):
    asserter({'format': 'date-time'}, 'a', 'a', formats={
        'date-time': r'^[ab]$',
    })


def test_disable_formats(asserter):
    asserter({'format': 'date-time'}, 'bla', 'bla', use_formats=False)

